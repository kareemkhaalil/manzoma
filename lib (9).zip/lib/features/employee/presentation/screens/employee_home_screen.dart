import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:manzoma/core/storage/shared_pref_helper.dart';

class EmployeeHomeScreen extends StatefulWidget {
  const EmployeeHomeScreen({super.key});

  @override
  State<EmployeeHomeScreen> createState() => _EmployeeHomeScreenState();
}

class _EmployeeHomeScreenState extends State<EmployeeHomeScreen>
    with TickerProviderStateMixin {
  String _userName = "الموظف";
  bool _isCheckedIn = false;
  late Timer _timer;
  DateTime _now = DateTime.now();

  // Animation controllers for pulse & staggered items
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late List<Animation<double>> _staggeredAnimations;

  @override
  void initState() {
    super.initState();
    _loadUserData();

    // clock update
    _now = DateTime.now();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      setState(() => _now = DateTime.now());
    });

    // pulse animation
    _pulseController =
        AnimationController(vsync: this, duration: const Duration(seconds: 2))
          ..repeat();
    _pulseAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeOut),
    );

    // staggered animations for quick action cards
    final base = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    base.forward();
    _staggeredAnimations = List.generate(
      4,
      (i) => CurvedAnimation(
        parent: base,
        curve: Interval(0.15 * i, 0.6 + 0.1 * i, curve: Curves.easeOut),
      ),
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  void _loadUserData() {
    final user = SharedPrefHelper.getUser();
    if (user != null) {
      setState(() {
        _userName = user.name ?? "الموظف";
      });
    }
  }

  // Simple sample data for mini bar chart (you can replace with real data)
  final List<double> _weekData = [0.8, 0.6, 0.9, 0.4, 0.7, 0.5, 0.85];

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width > 600;
    final primary = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: SafeArea(
        child: Column(
          children: [
            // Animated header
            _buildHeader(context, primary),

            // Body content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                    horizontal: isTablet ? 28.0 : 16.0, vertical: 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 6),
                    // Attendance circle with pulse
                    Center(child: _buildPulseAttendance(context, isTablet)),
                    SizedBox(height: isTablet ? 30 : 20),
                    // Quick actions (staggered)
                    _buildQuickActions(context, isTablet, primary),
                    SizedBox(height: isTablet ? 28 : 18),
                    // Mini summary + chart card
                    _buildSummaryWithChart(context, isTablet, primary),
                    const SizedBox(height: 22),
                    // Optional: other content placeholder
                  ],
                ),
              ),
            ),

            // Bottom nav
            _buildBottomNavigation(context, primary),
          ],
        ),
      ),
    );
  }

  // ================= Header =================
  Widget _buildHeader(BuildContext context, Color primary) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 700),
      curve: Curves.easeOut,
      builder: (context, t, _) {
        return Transform.translate(
          offset: Offset(0, 20 * (1 - t)),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  primary,
                  primary.withOpacity(0.85),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(18),
                bottomRight: Radius.circular(18),
              ),
              boxShadow: [
                BoxShadow(
                  color: primary.withOpacity(0.15),
                  blurRadius: 18,
                  offset: const Offset(0, 6),
                )
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    // Small avatar circle (static)
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.person, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "مرحباً، $_userName",
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "${_now.day}/${_now.month}/${_now.year}",
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => _showSettingsMenu(context),
                      icon: const Icon(Icons.more_vert, color: Colors.white),
                    )
                  ],
                ),
                const SizedBox(height: 12),
                // small live-time row
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        "${_now.hour.toString().padLeft(2, '0')}:${_now.minute.toString().padLeft(2, '0')}",
                        style:
                            const TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        "اضغط لبدء تسجيل حضورك أو الانصراف — واجهة مختصرة وسريعة",
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.95),
                            fontSize: 13),
                        overflow: TextOverflow.ellipsis,
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ================= Pulse Attendance =================
  Widget _buildPulseAttendance(BuildContext context, bool isTablet) {
    final circleSize = isTablet ? 230.0 : 190.0;
    final primary = Theme.of(context).primaryColor;

    return SizedBox(
      width: circleSize + 60,
      height: circleSize + 60,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Pulse layers (repeating using animation)
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              final value = _pulseAnimation.value;
              final opacity = (1 - value).clamp(0.0, 1.0);
              final sizeFactor = 1 + value * 1.2;
              return Opacity(
                opacity: opacity * 0.6,
                child: Container(
                  width: circleSize * sizeFactor,
                  height: circleSize * sizeFactor,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        primary.withOpacity(0.14 * opacity),
                        Colors.transparent
                      ],
                    ),
                  ),
                ),
              );
            },
          ),

          // Main circle (clickable)
          GestureDetector(
            onTap: _handleAttendanceAction,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 450),
              width: circleSize,
              height: circleSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _isCheckedIn
                      ? [Colors.greenAccent.shade400, Colors.green.shade700]
                      : [primary.withOpacity(0.95), primary.withOpacity(0.7)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: (_isCheckedIn ? Colors.green : primary)
                        .withOpacity(0.28),
                    blurRadius: _isCheckedIn ? 28 : 18,
                    offset: const Offset(0, 10),
                    spreadRadius: _isCheckedIn ? 6 : 2,
                  ),
                ],
                border: Border.all(
                  color: Colors.white.withOpacity(0.06),
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: Icon(
                        _isCheckedIn
                            ? Icons.logout_rounded
                            : Icons.login_rounded,
                        key: ValueKey<bool>(_isCheckedIn),
                        size: isTablet ? 56 : 46,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _isCheckedIn ? "تسجيل انصراف" : "تسجيل حضور",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isTablet ? 20 : 16,
                        fontWeight: FontWeight.w700,
                        shadows: [
                          Shadow(
                              color: Colors.black.withOpacity(0.18),
                              blurRadius: 6,
                              offset: const Offset(0, 3))
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    // optional subtext
                    Text(
                      _isCheckedIn ? "اضغط للخروج" : "اضغط للدخول",
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.85), fontSize: 12),
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================= Quick Actions =================
  Widget _buildQuickActions(
      BuildContext context, bool isTablet, Color primary) {
    final actions = [
      {'icon': Icons.insert_chart, 'title': 'إحصاءات', 'route': '/reports'},
      {
        'icon': Icons.history,
        'title': 'سجل الحضور',
        'route': '/employee/attendance'
      },
      {'icon': Icons.person, 'title': 'حسابي', 'route': '/profile'},
      {'icon': Icons.help_outline, 'title': 'المساعدة', 'route': '/help'},
    ];

    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: isTablet ? 4 : 2,
      crossAxisSpacing: 14,
      mainAxisSpacing: 14,
      childAspectRatio: 1.05,
      physics: const NeverScrollableScrollPhysics(),
      children: List.generate(actions.length, (i) {
        final action = actions[i];
        return FadeTransition(
          opacity: _staggeredAnimations[i],
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - _staggeredAnimations[i].value)),
            child: _quickActionCard(context, action, primary),
          ),
        );
      }),
    );
  }

  Widget _quickActionCard(BuildContext context, Map action, Color primary) {
    final color = Colors
        .primaries[action['title'].hashCode % Colors.primaries.length].shade400;
    return GestureDetector(
      onTap: () {
        final route = action['route'] as String;
        // If route exists in app router use it, otherwise fallback to snackbar
        try {
          GoRouter.of(context).go(route);
        } catch (_) {
          _handleQuickAction(action['title'] as String);
        }
      },
      child: Card(
        elevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color.withOpacity(0.14), color.withOpacity(0.04)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                        color: color.withOpacity(0.08),
                        blurRadius: 10,
                        offset: const Offset(0, 6))
                  ],
                ),
                child: Icon(action['icon'] as IconData, color: color),
              ),
              const SizedBox(height: 12),
              Text(
                action['title'] as String,
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================= Summary + Mini Chart =================
  Widget _buildSummaryWithChart(
      BuildContext context, bool isTablet, Color primary) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // header row
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      color: primary.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      Icon(Icons.show_chart, color: primary, size: 18),
                      const SizedBox(width: 8),
                      Text("ملخص الأداء", style: TextStyle(color: primary)),
                    ],
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    try {
                      GoRouter.of(context).go('/reports');
                    } catch (_) {}
                  },
                  child: const Text("عرض الكل"),
                )
              ],
            ),
            const SizedBox(height: 12),
            // mini bar chart
            SizedBox(
              height: 90,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: List.generate(_weekData.length, (i) {
                  final v = _weekData[i];
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          AnimatedContainer(
                            duration: Duration(milliseconds: 500 + i * 80),
                            height: 80 * v,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              gradient: LinearGradient(
                                colors: [
                                  primary.withOpacity(0.95),
                                  primary.withOpacity(0.6)
                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                              ),
                              boxShadow: [
                                BoxShadow(
                                    color: primary.withOpacity(0.12),
                                    blurRadius: 8,
                                    offset: const Offset(0, 4))
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            ["S", "M", "T", "W", "T", "F", "S"][i],
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
            const SizedBox(height: 12),
            // summary rows
            Row(
              children: [
                _smallStat("حضور اليوم", _isCheckedIn ? "تم" : "لم يتم",
                    icon: Icons.login, color: Colors.green),
                const SizedBox(width: 10),
                _smallStat("إجمالي الساعات", "8:00",
                    icon: Icons.access_time, color: Colors.orange),
                const SizedBox(width: 10),
                _smallStat("غياب", "0", icon: Icons.cancel, color: Colors.red),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _smallStat(String title, String value,
      {required IconData icon, required Color color}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(value,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  // ================= Bottom Navigation =================
  Widget _buildBottomNavigation(BuildContext context, Color primary) {
    final items = [
      {"icon": Icons.home, "label": "الرئيسية"},
      {"icon": Icons.schedule, "label": "الحضور"},
      {"icon": Icons.assignment, "label": "التقارير"},
      {"icon": Icons.person, "label": "حسابي"},
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 16),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(items.length, (i) {
          final it = items[i];
          final isActive = i == 0;
          return GestureDetector(
            onTap: () {
              // simple routing logic; map to app routes if exist
              if (i == 1) {
                try {
                  GoRouter.of(context).go('/employee/attendance');
                } catch (_) {}
              } else if (i == 2) {
                try {
                  GoRouter.of(context).go('/reports');
                } catch (_) {}
              } else if (i == 3) {
                try {
                  GoRouter.of(context).go('/profile');
                } catch (_) {}
              }
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 310),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: isActive
                  ? BoxDecoration(
                      color: primary.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    )
                  : null,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(it['icon'] as IconData,
                      color: isActive ? primary : Colors.grey, size: 22),
                  const SizedBox(height: 6),
                  Text(
                    it['label'] as String,
                    style: TextStyle(
                        fontSize: 12,
                        color: isActive ? primary : Colors.grey,
                        fontWeight:
                            isActive ? FontWeight.w700 : FontWeight.w500),
                  )
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  // ================= Actions =================
  void _handleAttendanceAction() {
    setState(() => _isCheckedIn = !_isCheckedIn);

    // Here add your actual check-in/out usecase calls.
    // For now we just show snackbar and simple state change.
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            _isCheckedIn ? "تم تسجيل الحضور بنجاح" : "تم تسجيل الانصراف بنجاح"),
        backgroundColor: _isCheckedIn ? Colors.green : Colors.orange,
      ),
    );
  }

  void _handleQuickAction(String title) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("تم النقر على: $title")));
  }

  void _showSettingsMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 18.0, horizontal: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.settings),
                title: const Text("الإعدادات"),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text("تسجيل الخروج"),
                onTap: () {
                  Navigator.pop(context);
                  GoRouter.of(context).go('/login');
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
