import 'package:flutter/material.dart';

class LocaleState {
  final Locale locale;

  LocaleState({required this.locale});
}

