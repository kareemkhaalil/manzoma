// import 'package:flutter/material.dart';

// class AppTheme {
//   static final lightTheme = ThemeData(
//     brightness: Brightness.light,
//     primarySwatch: Colors.indigo,
//     useMaterial3: true,
//   );

//   static final darkTheme = ThemeData(
//     brightness: Brightness.dark,
//     primarySwatch: Colors.indigo,
//     useMaterial3: true,
//   );
// }
